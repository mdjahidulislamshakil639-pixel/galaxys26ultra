UPLOAD YOUR IMAGE FILES HERE
===========================================================================

The site uses WebP exclusively (30% smaller than JPG, supported by all
modern browsers including Chrome, Firefox, Safari 14+, Edge, and all
mobile browsers from 2020 onwards).

===========================================================================
  COMPLETE FILE LIST (28 WebP files)
===========================================================================

## HERO IMAGE (used as video poster + preload)
  s26-ultra-hero.webp                         (1920x1080 recommended)

## COBALT VIOLET — 6 angles
  s26-ultra-cobalt-violet-primary.webp        (straight-on front)
  s26-ultra-cobalt-violet-angle.webp          (3/4 perspective view)
  s26-ultra-cobalt-violet-back.webp           (back showing camera module)
  s26-ultra-cobalt-violet-side.webp           (profile/thin edge)
  s26-ultra-cobalt-violet-front.webp          (screen-on front view)
  s26-ultra-cobalt-violet-detail.webp         (camera module close-up)

## SKY BLUE — 6 angles
  s26-ultra-sky-blue-primary.webp
  s26-ultra-sky-blue-angle.webp
  s26-ultra-sky-blue-back.webp
  s26-ultra-sky-blue-side.webp
  s26-ultra-sky-blue-front.webp
  s26-ultra-sky-blue-detail.webp

## BLACK — 6 angles
  s26-ultra-black-primary.webp
  s26-ultra-black-angle.webp
  s26-ultra-black-back.webp
  s26-ultra-black-side.webp
  s26-ultra-black-front.webp
  s26-ultra-black-detail.webp

## WHITE — 6 angles
  s26-ultra-white-primary.webp
  s26-ultra-white-angle.webp
  s26-ultra-white-back.webp
  s26-ultra-white-side.webp
  s26-ultra-white-front.webp
  s26-ultra-white-detail.webp

## MISC / LOGOS
  logo.png                                    (your site logo, 512x512)
  samsung-logo.png                            (Samsung logo for VideoObject)
  s26-ultra-video-thumb.webp                  (video sitemap thumbnail)

===========================================================================
  HOW TO CREATE WEBP FROM ANY SOURCE IMAGE (JPG/PNG)
===========================================================================

## Option 1: Online (easiest, no install)
  1. Go to https://squoosh.app/
  2. Drag your source image in
  3. Right panel -> Format: WebP, Quality: 85
  4. Click Download
  5. Rename to match the target filename above

## Option 2: Command line bulk conversion
  Install cwebp:
    Ubuntu/Debian:  sudo apt install webp
    macOS:          brew install webp
    Windows:        download from developers.google.com/speed/webp/download

  Convert a single file:
    cwebp -q 85 input.jpg -o output.webp

  Bulk convert entire folder of JPGs to WebP:
    for file in *.jpg; do
      cwebp -q 85 "$file" -o "${file%.jpg}.webp"
    done

  Same for PNGs:
    for file in *.png; do
      cwebp -q 85 "$file" -o "${file%.png}.webp"
    done

## Option 3: ImageMagick
    magick input.jpg -quality 85 output.webp

===========================================================================
  TARGET FILE SIZES (for Bangladesh 4G performance)
===========================================================================

  Hero (1920x1080):        WebP <= 150 KB
  Product angles:          WebP <= 80 KB
  Detail shots:            WebP <= 70 KB

Total image weight target: under 3 MB for all 28 WebPs combined.

===========================================================================
  WHERE TO GET SOURCE IMAGES
===========================================================================

  - Samsung press kit:       https://news.samsung.com/global/
  - GSMArena product page:   https://www.gsmarena.com/samsung_galaxy_s26_ultra
  - Official Samsung store:  https://www.samsung.com/global/galaxy/galaxy-s26-ultra/

  Samsung press photos are free for editorial use with attribution.

===========================================================================
  IF YOU ONLY HAVE 4 IMAGES (one per color) FOR NOW — QUICK START
===========================================================================

You can start with just 4 images by duplicating across all 6 angles.
The site still works while you gather more angle shots later.

Example: copy s26-ultra-cobalt-violet.webp 6 times with different names:
    s26-ultra-cobalt-violet-primary.webp
    s26-ultra-cobalt-violet-angle.webp
    s26-ultra-cobalt-violet-back.webp
    s26-ultra-cobalt-violet-side.webp
    s26-ultra-cobalt-violet-front.webp
    s26-ultra-cobalt-violet-detail.webp

Later replace with actual angle-specific shots.

===========================================================================
  SEO BONUS: Samsung.com / Samsung BD press images are safe to use
===========================================================================

  Galaxy S26 Ultra press kit:
  https://news.samsung.com/us/galaxy-s26-ultra-press-kit/

  These are officially released for editorial + commercial use.
  No attribution required unless specified.
  Download high-res (2000px+) source images, convert to WebP at 1000x1200.
