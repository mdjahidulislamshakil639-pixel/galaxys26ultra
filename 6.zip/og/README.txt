UPLOAD OPEN GRAPH IMAGES HERE

Required:
  - s26-ultra-price-bd.webp  (1200x630 social share image for homepage)

Optional per sub-page:
  - camera-review.webp
  - vs-s25-ultra.webp
  - vs-iphone-17-pro-max.webp
  - emi.webp
  - official-vs-unofficial.webp
  - showrooms-dhaka.webp
  - faq.webp
  - bn.webp

See OG-IMAGE-SPEC.md in /docs/ for the design template.
Target size: Under 300KB each. 1200x630 dimensions required.
