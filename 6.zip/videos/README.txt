UPLOAD YOUR VIDEO FILES HERE

Referenced in HTML:
  - s26-ultra-hero.webm     (hero video background, WebM, <500KB ideal)
  - s26-ultra-motion.webm   (motion section video, WebM, <500KB)

If WebM files not present, the HTML falls back to MP4 hosted at images.samsung.com.

To create WebM from existing MP4 using ffmpeg:
  ffmpeg -i s26-ultra-hero.mp4 -c:v libvpx-vp9 -crf 35 -b:v 0 -an s26-ultra-hero.webm

Target: Under 500KB per file for BD 4G performance.
